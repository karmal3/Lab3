package laborai.studijosktu;

public enum HashType {

    DIVISION, 
    MULTIPLICATION, 
    JCF7, //Java Collections Framework 7 
    JCF8  //Java Collections Framework 8
}

